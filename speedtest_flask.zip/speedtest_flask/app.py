# app.py

from flask import Flask, render_template, jsonify
import speedtest

app = Flask(__name__)

# Create a speedtest object
st = speedtest.Speedtest()

# Define routes
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/speedtest')
def speedtest_results():
    st.get_best_server()
    download_speed = st.download() / 1_000_000  # Convert to Mbps
    upload_speed = st.upload() / 1_000_000  # Convert to Mbps
    ping = st.results.ping

    return jsonify({
        'download_speed': round(download_speed, 2),
        'upload_speed': round(upload_speed, 2),
        'ping': ping
    })

if __name__ == '__main__':
    app.run(debug=True)
